const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("[⚡] Veja a velocidade do bot."),
  async execute(interaction, client) {
    const ping = Math.max(0, Date.now() - interaction.createdTimestamp);
    const api = Math.round(client.ws.ping);
    const embed = new EmbedBuilder()
      .setTitle("⚡ Status do Bot")
      .setDescription(`Bot online e respondendo rápido.\n\n**Resposta:** ${ping}ms\n**API Discord:** ${api}ms\n**Uptime:** <t:${Math.floor((Date.now() - process.uptime()*1000)/1000)}:R>`)
      .setColor("#57F287")
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
