const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("protecoes")
    .setDescription("[🛡️] Mostra as proteções premium do bot."),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle("🛡️ Proteções ativas")
      .setDescription([
        "✅ Anti-crash global",
        "✅ Anti-spam básico",
        "✅ Anti-link por ENV `ANTILINK=ON`",
        "✅ Logs por `LOG_WEBHOOK` ou `LOG_CHANNEL_ID`",
        "✅ Backup automático das databases",
        "✅ Status rotativo",
        "✅ Servidor web para Render",
        "✅ Respostas de erro mais seguras"
      ].join("\n"))
      .setColor("#5865F2")
      .setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
