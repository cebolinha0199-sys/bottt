const { SlashCommandBuilder, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { backupDatabases } = require("../../../Functions/premium-core");
const { JsonDatabase } = require("wio.db");
const { getCache } = require("../../../Functions/connect_api");
const dbPerms = new JsonDatabase({ databasePath: "./databases/dbPermissions.json" });

module.exports = {
  data: new SlashCommandBuilder()
    .setName("backup")
    .setDescription("[💾] Cria um backup manual das databases."),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const dono = getCache(null, "owner");
    const isOwner = interaction.user.id === dono;
    const isVendas = (await dbPerms.get("vendas"))?.includes(interaction.user.id);
    const isTicket = (await dbPerms.get("ticket"))?.includes(interaction.user.id);
    if (!isOwner && !isVendas && !isTicket) {
      return interaction.editReply({ content: "❌ Você não tem permissão para usar este comando." });
    }
    const file = backupDatabases();
    if (!file) return interaction.editReply({ content: "❌ Não consegui criar o backup." });
    const embed = new EmbedBuilder()
      .setTitle("💾 Backup criado")
      .setDescription("Backup manual criado com sucesso. Guarde esse arquivo em local seguro.")
      .setColor("#57F287")
      .setTimestamp();
    return interaction.editReply({ embeds: [embed], files: [new AttachmentBuilder(file)] });
  }
};
