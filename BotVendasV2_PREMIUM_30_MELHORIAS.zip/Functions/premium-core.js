const fs = require("fs");
const path = require("path");
const { EmbedBuilder, WebhookClient, ActivityType } = require("discord.js");

const spamMap = new Map();
const linkRegex = /(https?:\/\/|www\.|discord\.gg\/|\.com\b|\.net\b|\.gg\b)/i;

function createEmbed({ title="Sistema", description="", color="#5865F2", image=null, footer="Bot Premium • Sistema automático" } = {}) {
  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(description || "\u200b")
    .setTimestamp()
    .setFooter({ text: footer });
  if (image) embed.setImage(image);
  return embed;
}

function setupWebServer(client) {
  try {
    const express = require("express");
    const app = express();
    app.get("/", (req, res) => {
      res.status(200).send(`Bot online: ${client?.user?.tag || "iniciando"}`);
    });
    app.get("/health", (req, res) => res.json({ ok: true, uptime: process.uptime() }));
    const port = process.env.PORT || 3000;
    app.listen(port, () => console.log(`[WEB] Servidor ligado na porta ${port}`));
  } catch (err) {
    console.log("[WEB] Express não iniciou:", err.message);
  }
}

function setupAntiCrash() {
  const log = (name, error) => {
    const msg = error?.stack || error?.message || String(error);
    console.log(`\n[ANTI-CRASH] ${name}\n${msg}\n`);
  };
  process.on("unhandledRejection", (reason) => log("Unhandled Rejection", reason));
  process.on("uncaughtException", (err) => log("Uncaught Exception", err));
  process.on("uncaughtExceptionMonitor", (err) => log("Exception Monitor", err));
  process.on("multipleResolutions", (type, promise, reason) => log(`Multiple Resolutions: ${type}`, reason));
}

function safeJsonRead(file) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch (_) { return null; }
}

function backupDatabases() {
  const sourceDir = path.join(process.cwd(), "databases");
  const backupDir = path.join(process.cwd(), "backups");
  if (!fs.existsSync(sourceDir)) return null;
  fs.mkdirSync(backupDir, { recursive: true });
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const outFile = path.join(backupDir, `backup-${timestamp}.json`);
  const payload = { createdAt: new Date().toISOString(), files: {} };
  for (const file of fs.readdirSync(sourceDir)) {
    const full = path.join(sourceDir, file);
    if (!fs.statSync(full).isFile()) continue;
    payload.files[file] = safeJsonRead(full) ?? fs.readFileSync(full, "utf8");
  }
  fs.writeFileSync(outFile, JSON.stringify(payload, null, 2));
  const old = fs.readdirSync(backupDir).filter(f => f.startsWith("backup-")).sort();
  while (old.length > 20) {
    fs.rmSync(path.join(backupDir, old.shift()), { force: true });
  }
  console.log(`[BACKUP] Criado: ${outFile}`);
  return outFile;
}

function setupAutoBackup(minutes = 30) {
  try {
    backupDatabases();
    setInterval(() => backupDatabases(), Math.max(5, minutes) * 60 * 1000);
  } catch (err) {
    console.log("[BACKUP] Falha:", err.message);
  }
}

async function sendLog(client, title, description, color="#5865F2") {
  try {
    const webhook = process.env.LOG_WEBHOOK;
    const embed = createEmbed({ title, description, color, footer: "Logs • Bot Premium" });
    if (webhook) {
      const wh = new WebhookClient({ url: webhook });
      await wh.send({ embeds: [embed] });
      return;
    }
    const channelId = process.env.LOG_CHANNEL_ID;
    if (channelId && client?.channels) {
      const ch = await client.channels.fetch(channelId).catch(() => null);
      if (ch?.send) await ch.send({ embeds: [embed] });
    }
  } catch (err) {
    console.log("[LOG] Falha ao enviar log:", err.message);
  }
}

function setupStatusRotator(client) {
  const statuses = [
    "⚙️ Sistema premium online",
    "🎫 Tickets rápidos",
    "🛒 Vendas automáticas",
    "🛡️ Proteção ativa",
    "💾 Backup automático"
  ];
  let i = 0;
  const update = () => {
    if (!client?.user) return;
    client.user.setPresence({
      activities: [{ name: statuses[i++ % statuses.length], type: ActivityType.Custom }],
      status: "online"
    });
  };
  update();
  setInterval(update, 60 * 1000);
}

async function securityMessageGuard(message) {
  if (!message || message.author?.bot || !message.guild) return false;
  const member = message.member;
  if (member?.permissions?.has?.("Administrator")) return false;

  const now = Date.now();
  const key = `${message.guild.id}:${message.author.id}`;
  const data = spamMap.get(key) || { count: 0, ts: now, warned: false };
  if (now - data.ts > 7000) { data.count = 0; data.ts = now; data.warned = false; }
  data.count++;
  spamMap.set(key, data);

  if (process.env.ANTILINK === "ON" && linkRegex.test(message.content || "")) {
    await message.delete().catch(() => null);
    const warn = await message.channel.send({ embeds: [createEmbed({ title: "Link bloqueado", description: `${message.author}, links não são permitidos aqui.`, color: "#ED4245" })] }).catch(() => null);
    if (warn) setTimeout(() => warn.delete().catch(() => null), 5000);
    return true;
  }

  if (data.count >= 6) {
    await message.delete().catch(() => null);
    if (!data.warned) {
      data.warned = true;
      const warn = await message.channel.send({ embeds: [createEmbed({ title: "Anti-spam", description: `${message.author}, pare de enviar mensagens muito rápido.`, color: "#FEE75C" })] }).catch(() => null);
      if (warn) setTimeout(() => warn.delete().catch(() => null), 6000);
    }
    return true;
  }
  return false;
}

module.exports = {
  createEmbed,
  setupWebServer,
  setupAntiCrash,
  setupAutoBackup,
  backupDatabases,
  sendLog,
  setupStatusRotator,
  securityMessageGuard
};
