const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const dbConfigs = new JsonDatabase({ databasePath: "./databases/dbConfigs.json" });

const painelImage = "https://public-blob.squarecloud.dev/1057518718378324009/bannernevermiss_m9n255ii-c1a0.png";
const color = () => dbConfigs.get("color") || "#5865F2";

function mainEmbed() {
  return new EmbedBuilder()
    .setTitle("⚙️ Painel Central do Bot")
    .setDescription([
      "Escolha abaixo o módulo que você quer configurar.",
      "",
      "🛒 **Vendas** — produtos, estoque, cupons e pagamentos.",
      "🎫 **Ticket** — atendimento, painel e categorias.",
      "👋 **Boas-vindas** — entrada de membros e mensagens.",
      "🛡️ **Moderação** — proteção e comandos de staff.",
      "💾 **Rendimentos/Backups** — controle e segurança."
    ].join("\n"))
    .setColor(color())
    .setImage(painelImage)
    .setFooter({ text: "Painel Premium • Sistema automático" })
    .setTimestamp();
}

async function StartAll(client, interaction) {
  const components = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("configVendas").setLabel("Vendas").setEmoji("🛒").setStyle(1),
    new ButtonBuilder().setCustomId("configticket").setLabel("Ticket").setEmoji("🎫").setStyle(1),
    new ButtonBuilder().setCustomId("configBemvindo").setLabel("Boas vindas").setEmoji("👋").setStyle(1),
    new ButtonBuilder().setCustomId("configAutomaticas").setLabel("Ações Auto").setEmoji("⚡").setStyle(2)
  );

  const components2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("configbot").setLabel("Personalização").setEmoji("🎨").setStyle(1),
    new ButtonBuilder().setCustomId("rendimentosBot").setLabel("Rendimentos").setEmoji("💰").setStyle(3),
    new ButtonBuilder().setCustomId("e-salesPainel").setLabel("e-Sales").setEmoji("💼").setStyle(2).setDisabled(true),
    new ButtonBuilder().setCustomId("configModeracao").setLabel("Moderação").setEmoji("🛡️").setStyle(4)
  );

  const payload = { embeds: [mainEmbed()], components: [components, components2], files: [] };
  if (interaction.isButton?.() || interaction.isStringSelectMenu?.() || interaction.isSelectMenu?.()) {
    return interaction.update(payload);
  }
  return interaction.editReply(payload);
}

async function botConfigTickets(client, interaction) {
  return interaction.update({
    files: [],
    embeds: [
      new EmbedBuilder()
        .setTitle("🎫 Configuração de Ticket")
        .setDescription("Configure atendimento, painéis, categoria, logs e sugestões pelos botões abaixo.")
        .setColor(color())
        .setFooter({ text: "Ticket Premium • Sistema automático" })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setStyle(2).setCustomId("configticket").setLabel("Configurar Ticket").setEmoji("🎫"),
        new ButtonBuilder().setStyle(2).setCustomId("configsugestsistem").setLabel("Sistema Sugestão").setEmoji("💬")
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltarconfiginicio").setLabel("Voltar").setEmoji("⬅️").setStyle(1)
      )
    ]
  });
}

module.exports = { botConfigTickets, StartAll };
