const fs = require('fs');
const path = require('path');

let fileConfig = {};
try {
  const tokenPath = path.join(__dirname, 'token.json');
  if (fs.existsSync(tokenPath)) {
    fileConfig = require(tokenPath);
  }
} catch (_) {
  fileConfig = {};
}

module.exports = {
  ...fileConfig,
  token: process.env.TOKEN || fileConfig.token || fileConfig.TOKEN || '',
  ID_DONO: process.env.ID_DONO || fileConfig.ID_DONO || fileConfig.owner || '',
};
