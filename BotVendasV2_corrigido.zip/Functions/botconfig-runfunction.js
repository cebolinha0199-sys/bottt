const { MessageFlags, EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ModalBuilder, TextInputBuilder, ActivityType, ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ChannelType } = require("discord.js")
const axios = require("axios")
const url = require("node:url")

const { JsonDatabase } = require("wio.db")
const dbConfigs = new JsonDatabase({ databasePath: "./databases/dbConfigs.json" })
const dbe = new JsonDatabase({ databasePath: "./databases/emojis-globais.json" });


async function StartAll(client, interaction) {
    const image = `https://public-blob.squarecloud.dev/1057518718378324009/bannernevermiss_m9n255ii-c1a0.png`;

    const components = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`configVendas`).setLabel(`Vendas`).setStyle(1), //<:home:1334618559447568426>
        new ButtonBuilder().setCustomId(`configticket`).setLabel(`Ticket`).setStyle(1),
        new ButtonBuilder().setCustomId(`configBemvindo`).setLabel(`Boas vindas`).setStyle(1),
        new ButtonBuilder().setCustomId(`configAutomaticas`).setLabel(`Ações Automáticas`).setStyle(2),
    );

    const components2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`configbot`).setLabel(`Personalização`).setStyle(1),
        new ButtonBuilder().setCustomId(`rendimentosBot`).setLabel(`Rendimentos`).setStyle(3),
        new ButtonBuilder().setCustomId(`e-salesPainel`).setLabel(`e-Sales`).setStyle(2).setDisabled(true),
        new ButtonBuilder().setCustomId(`configModeracao`).setLabel(`Moderação`).setStyle(4),
    );

    // Verifica o tipo da interação e responde adequadamente
    if (interaction.isButton() || interaction.isSelectMenu()) {
        await interaction.update({
            components: [components, components2],
            files: [image],
            embeds: []
        });
    } else {
        await interaction.editReply({
            components: [components, components2],
            files: [image],
            embeds: []
        });
    }
}




async function botConfigTickets(client, interaction) {
    const voltarEmoji = `<:voltar:${await dbe.get('voltar')}>`;
    interaction.update({
        files: [],
        embeds: [
            new EmbedBuilder()
                .setTitle(`Configuração Sistemas Automáticos`)
                .setDescription(`Selecione um dos botões abaixo para configurar o seu bot!`)
                .setColor(dbConfigs.get(`color`) || "Default")
        ], components: [
            new ActionRowBuilder()
                .addComponents(
                    //new ButtonBuilder().setStyle(2).setCustomId(`configbot`).setLabel(`Configurar Bot`),
                    new ButtonBuilder()
                        .setStyle(2)
                        .setCustomId(`configticket`)
                        .setLabel(`Configurar Ticket`)
                        ,
                    new ButtonBuilder()
                        .setStyle(2)
                        .setCustomId(`configsugestsistem`)
                        .setLabel(`Configurar Sistema Sugestão`)
                        
                ),
            new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId(`voltarconfiginicio`).setStyle(1)
                )

        ]
    })
}

module.exports = {
    botConfigTickets,
    StartAll
};